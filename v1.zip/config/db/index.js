const mongoose = require("mongoose");
const { DB_USER, DB_PASS, DB_NAME } = require("../");

mongoose.connect(
 `mongodb://localhost:27017/testDB`
);

module.exports = mongoose;
