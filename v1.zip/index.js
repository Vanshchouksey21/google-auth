const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("./config/db");
const morgan = require("morgan");
const cors = require("cors");
const routes = require("./routes");
const User = require("./models/user/index");
const app = express();
const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;

const path = require('path');

// Serve static files from "public" folder
app.use(express.static(path.join(__dirname, 'public')));


// // * Database connection
var db = mongoose.connection;
db.on("error", console.error.bind(console, "connection error:"));
db.once("open", function () {
  console.log("db connected!");
});

// * Cors
app.use(cors());

// * Body Parser
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(morgan("short"));

app.use(passport.initialize());

// * Api routes
app.use("/api", routes);


passport.use(
  new GoogleStrategy(
    {
      // clientID: GOOGLE_CLIENT_ID,
      // clientSecret: GOOGLE_CLIENT_SECRET,
      callbackURL: '/auth/google/callback',
      passReqToCallback: true,
    },
    async (req, accessToken, refreshToken, profile, done) => {
      try {
        
        let user = await User.findOne({ username: profile.id });
        if (!user) {
          user = await User.create({
          first_name: 'Jane',
          last_name: 'Smith',
          username: 'jane.smith',
          email: 'jane.smith@example.com',
          password: 'hashed_password_here', // should be hashed (use bcrypt)
          status: 'Active',
          type: new mongoose.Types.ObjectId('664dc1c52f45df001c82f111'), // Example user-type ID
          job_id: 'DEV123',
          });
        }
        console.log(req,accessToken,refreshToken,profile,done);
        return done(null, user);
      } catch (err) {
        return done(err, null);
      }
    }
  )
);



// Optional fallback
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/index.html'));
});


app.get(
  '/auth/google',
  passport.authenticate('google', { scope: ['profile', 'email'] })
);

app.get(
  '/auth/google/callback',
  passport.authenticate('google', { session: false, failureRedirect: '/' }),
  (req, res) => {
    console.log("Redirected here to callback");
    // const token = generateToken(req.user);
    res.send("google callback url hit");
    // // Redirect to frontend with token
    // res.redirect(`${process.env.FRONTEND_URL}/auth?token=${token}`);
  }
);


app.get("/", (req, res) => {
  console.log("hello");
  res.send("hello");
});

app.use("*", (req, res) => {
  res.send("Route not found");
});

let PORT = process.env.PORT || 3000;

app.listen(PORT, () => console.log(`Server is running on PORT ${PORT}`));
